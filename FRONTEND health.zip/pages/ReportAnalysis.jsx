import React, { useState, useEffect , useRef } from 'react';
import axios from 'axios';
import vdo from '../public/assets/report.mp4'
import { DotLottieReact } from "@lottiefiles/dotlottie-react";


function ReportAnalysis() {
    const [username, setUsername] = useState('');
    const [contact, setContact] = useState('');
    const [email, setEmail] = useState('');
    const [pdfFile, setPdfFile] = useState(null);
    const [medicalSummary, setMedicalSummary] = useState("");
    const [userprofile, setUserprofile] = useState(null);
    const [reportHistory, setreportHistory] = useState([]);
    const fileInputRef = useRef(null);


    const handleFileChange = (event) => {
        setPdfFile(event.target.files[0]);
    };

    useEffect(() => {
        const storedUser = sessionStorage.getItem("userProfileInfo");
        if (storedUser) {
            setUserprofile(JSON.parse(storedUser));
        }
    }, []);

    // 🔹 Updated useEffect: Fetch reports when userprofile is available
    useEffect(() => {
        if (userprofile) {
            fetchReports();
        }
    }, [userprofile]); // 🔥 Dependency array now includes userprofile


    const fetchReports = async () => {
        const email = userprofile?.email;
        const phone = userprofile?.contact;

        if (!email || !phone) return; // Ensure both values exist before making the request
        console.log("checking email before fetching report", email);
        console.log("checking phone before fetching report", phone);

        try {
            const response = await axios.get("http://127.0.0.1:4000/api/v1/report/fetch-report", {
                params: { email, phone },
            });

            console.log("✅ Data fetched successfully:", response.data.reports);
            setreportHistory(response.data.reports);

        } catch (error) {
            console.error("❌ Error fetching reports:", error);
        }
    };


    const handleUpload = async (event) => {
        event.preventDefault();

        if (!pdfFile) {
            console.error("❌ No file selected");
            return;
        }

        let userEmail = userprofile?.email
        console.log("current user Email is", userprofile?.email); // Check if email is available

        const formData = new FormData();
        formData.append("username", username);
        formData.append("contact", contact);
        formData.append("pdfFile", pdfFile); // ✅ Ensure correct file field
        formData.append("userEmail", userEmail)


        // ✅ Debugging FormData contents
        for (let pair of formData.entries()) {
            console.log(`📌 ${pair[0]}:`, pair[1]);
        }

        try {
            const response = await axios.post(
                "http://127.0.0.1:4000/api/v1/report/upload-report",
                formData,
                {
                    headers: {
                        // **Do NOT set Content-Type manually!**
                        // "Content-Type": "multipart/form-data",
                    },
                    // timeout: 10000,
                }
            );

            console.log("✅ Upload success:", response.data);
            setMedicalSummary(response.data.medicalSummary); // ✅ Update state with summary 
            fetchReports();// Fetch reports again after successful upload


        } catch (error) {
            console.error("❌ Upload error:", error.response ? error.response.data : error.message);
        }
    };

    const handleCardClick = (report) => {
        alert(`Report ID: ${report._id}`);
        // You can navigate or open a modal here
    };

    // const handleFileChange = (e) => {
    //   setSelectedFile(e.target.files[0]);
    // };
  
    const handleUploadClick = () => {
      fileInputRef.current.click();
    };

    return (
        <div>
  <div className=" flex justify-center min-h-screen px-4">
  {/* <video
            autoPlay
            loop
            muted
            className="absolute z-0 top-0 left-0 w-full object-cover"
          >
            <source src='../public/assets/report.mp4' type="video/mp4" />
            Your browser does not support the video tag.
          </video> */}
  <div className="w-1/2 p-8 mt-7 max-h-[600px] flex flex-col  bg-white rounded-l-lg shadow-lg border ">
        <h2 className="text-3xl font-bold text-center text-gray-900 mb-6">
          Upload Report
        </h2>
        <form onSubmit={handleUpload} className="space-y-4">
          <div>
            <input
              type="text"
              placeholder="Username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
              className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-cyan-500"
            />
          </div>
          <div>
            <input
              type="text"
              placeholder="Phone Number"
              value={contact}
              onChange={(e) => setContact(e.target.value)}
              required
              className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-cyan-500"
            />
          </div>
          {/* <div>
            <input
              type="file"
              accept="application/pdf"
              onChange={handleFileChange}
              required
              className="w-full p-3 border border-gray-300 rounded-md bg-gray-50 cursor-pointer focus:outline-none focus:ring-2 focus:ring-cyan-500"
            />
          </div> */}
          <div className="w-full h-76 border-2 border-dashed border-black rounded-md flex items-center justify-center relative">
      <input
        type="file"
        accept="application/pdf"
        onChange={handleFileChange}
        ref={fileInputRef}
        className="hidden" // Hide the default input
      />

      {/* Circular Upload Button */}
      <div
        className="w-16 h-16 rounded-full bg-cyan-500 text-white flex items-center justify-center cursor-pointer"
        onClick={handleUploadClick}
      >
        {/* You can add an upload icon here (e.g., using Heroicons) */}
        <svg
          xmlns="http://www.w3.org/2000/svg"
          className="h-8 w-8"
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"
          />
        </svg>
      </div>
    </div>
          <button
            type="submit"
            className="w-full bg-cyan-500 text-white py-3 rounded-md text-lg font-medium hover:bg-cyan-600 transition duration-300"
          >
            Upload
          </button>
        </form>
      </div>

      {/* Right Side: Lottie or Medical Summary */}
      <div className="w-1/2 p-4 mt-7 max-h-[600px] bg-gray-50 rounded-r-lg border-t border-b border-r border-black  flex flex-col justify-center items-center">
        {medicalSummary ? (
          <div className="w-full h-full overflow-y-auto scrollbar-hidden">
            <h3 className="text-xl font-semibold text-gray-900">Medical Summary:</h3>
            <pre className="bg-white p-4 rounded-md  text-gray-700 text-sm leading-relaxed whitespace-pre-wrap">
              {medicalSummary}
            </pre>
            <p className="text-sm font-bold text-gray-600 mt-4">
              This information is generated by AI, so kindly reassure the information with your doctor.
            </p>
          </div>
        ) : (
          <div className="w-full flex flex-col justify-center items-center h-64">
            <DotLottieReact 
        src="https://lottie.host/4620f6fe-a1db-44db-9afe-8ffa1179c957/WrudsEiTb8.lottie" 
        background="transparent" 
        speed="1" 
        style={{ width: '300px', height: '300px' }}
        loop
        autoplay/>
          </div>
        )}
      </div>
</div>


<div className="p-6 bg-gradient-to-r from-blue-50 via-sky-100 to-blue-200 min-h-screen">
            <h2 className="text-3xl font-semibold text-gray-800 mb-6 text-center">📄 Report History</h2>
            {reportHistory.length === 0 ? (
                <p className="text-gray-600 text-center">No reports found.</p>
            ) : (
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 px-4 ">
                    {reportHistory.map((report) => (
                        <div 
                            key={report._id} 
                            onClick={() => handleCardClick(report)}
                            className="bg-gray-200 shadow-lg hover:shadow-xl  transition-all transform hover:-translate-y-1 rounded-xl p-6 border border-blue-200 cursor-pointer relative"
                        >
                            {/* <div className="absolute top-3 right-3 bg-blue-500 text-white text-xs px-3 py-1 rounded-full">
                                {new Date(report.createdAt).toLocaleDateString()}
                            </div> */}
                            <h3 className="text-xl font-bold text-blue-800 mb-2">{report.username}</h3>
                            <p className="text-gray-700"><span className="font-semibold">📧 Email:</span> {report.userEmail}</p>
                            <p className="text-gray-700"><span className="font-semibold">📞 Contact:</span> {report.contact}</p>
                            <p className="text-gray-600 text-sm mt-3">
                                <span className="font-semibold">⏳ Created:</span> {new Date(report.createdAt).toLocaleString()}
                            </p>
                        </div>
                    ))}
                </div>
            )}
        </div>

        </div>
    );
}

export default ReportAnalysis;
